using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    public snap_shot_camera snapcam;

    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // Press "C" to take snapshot
        if (Input.GetKeyDown(KeyCode.C))
        {
            if (snapcam != null)
            {
                snapcam.CallTakeSnapshot();
            }
            else
            {
                Debug.LogWarning("?? snap_shot_camera reference not set in Inspector!");
            }
        }
    }
}
