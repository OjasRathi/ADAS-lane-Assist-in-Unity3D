using UnityEngine;

public class smooth_mouse : MonoBehaviour
{
    [Header("Settings")]
    public float sensitivity = 2.0f;
    public float smoothing = 3.0f;
    public Vector2 clampInDegrees = new Vector2(360, 180);

    private Vector2 _mouseAbsolute;
    private Vector2 _smoothMouse;
    private Vector2 _targetDirection;

    void Start()
    {
        // Initialize target direction to the current rotation
        _targetDirection = transform.localRotation.eulerAngles;
    }

    void Update()
    {
        // Read raw mouse input
        Vector2 mouseDelta = new Vector2(Input.GetAxisRaw("Mouse X"), Input.GetAxisRaw("Mouse Y"));

        // Scale by sensitivity & smoothing
        mouseDelta = Vector2.Scale(mouseDelta, new Vector2(sensitivity * smoothing, sensitivity * smoothing));

        // Smooth the mouse movement
        _smoothMouse.x = Mathf.Lerp(_smoothMouse.x, mouseDelta.x, 1f / smoothing);
        _smoothMouse.y = Mathf.Lerp(_smoothMouse.y, mouseDelta.y, 1f / smoothing);

        // Accumulate the movement
        _mouseAbsolute += _smoothMouse;

        // Clamp vertical rotation
        if (clampInDegrees.y < 360f)
        {
            _mouseAbsolute.y = Mathf.Clamp(_mouseAbsolute.y, -clampInDegrees.y * 0.5f, clampInDegrees.y * 0.5f);
        }

        // Apply the rotation
        Quaternion xRotation = Quaternion.AngleAxis(-_mouseAbsolute.y, Vector3.right);
        Quaternion yRotation = Quaternion.AngleAxis(_mouseAbsolute.x, Vector3.up);

        transform.localRotation = xRotation * Quaternion.Euler(_targetDirection) * yRotation;
    }
}
