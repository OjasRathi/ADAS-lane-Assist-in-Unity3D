using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class car_controller : MonoBehaviour
{
    public WheelCollider front_right;
    public WheelCollider front_left;
    public WheelCollider rear_right;
    public WheelCollider rear_left;
    public Transform front_righttransform;
    public Transform front_lefttransform;
    public Transform rear_righttransform;
    public Transform rear_lefttransform;
    [HideInInspector] public float VerticalInput;
    [HideInInspector] public float HorizontalInput;

    float motorforce = 1000f;
    float Steeringangle = 20f;
    public Transform COMtransform;
    public Rigidbody rigidbody;
    float BrakeInput = 5000f;



   




    void Start()
    {
        rigidbody.centerOfMass = COMtransform.localPosition;

    }

  





    void FixedUpdate()
    {
        MotorForce();
        UpdateWheel();
        Getinput();
        Steering();
        ApplyBrake();
        PowerSteering();
        Debug.Log(carspeed());


    }

    
    
    
    
    
    
    
    void Getinput()
    {
        VerticalInput= Input.GetAxis("Vertical");
        HorizontalInput= Input.GetAxis("Horizontal");

     }

    void ApplyBrake()
    {

        if (Input.GetKey(KeyCode.Space))

        {

            front_left.brakeTorque = BrakeInput;
            front_right.brakeTorque = BrakeInput;
            rear_left.brakeTorque = BrakeInput;
            rear_right.brakeTorque = BrakeInput;
            rigidbody.drag = 1f;

        }
        else
        {
            front_left.brakeTorque = 0f;
            front_right.brakeTorque = 0f;
            rear_left.brakeTorque = 0f;
            rear_right.brakeTorque = 0f;
            rigidbody.drag = 0f;
        }

    }
   
    
    
    
    
    
    void MotorForce()
    {
        front_right.motorTorque = motorforce*VerticalInput;
        front_left.motorTorque = motorforce*VerticalInput;
    }


    public float carspeed()
    {
        float speed =rigidbody.velocity.magnitude*2.23693629f;
        return speed;


    }



    void Steering()
    {
        front_left.steerAngle = Steeringangle*HorizontalInput;
        front_right.steerAngle = Steeringangle*HorizontalInput;

    }

    void PowerSteering()
    {
        if(HorizontalInput==0)
        {
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.Euler(0f, 0f, 0f),Time.deltaTime);

        }
    }
   
    
    
    
    
    
    void UpdateWheel()
    {
        RotateWheel(front_left, front_lefttransform);
        RotateWheel(front_right, front_righttransform);
        RotateWheel(rear_left, rear_lefttransform);
        RotateWheel(rear_right,rear_righttransform);
    }

   
    
    
    
    void RotateWheel(WheelCollider wheelCollider , Transform transform)
    {
        Vector3 pos;
        Quaternion rot;
        wheelCollider.GetWorldPose(out pos, out rot);
        transform.position= pos;
        transform.rotation= rot;
     }






}
