using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class endless_city : MonoBehaviour
{
    public Transform PlayercarTransform;
    public Transform othercityTransform;
    public float halflength;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (PlayercarTransform.position.z>transform.position.z+ halflength+10f)
        {
            transform.position = new Vector3(0, 0, othercityTransform.position.z + halflength*2);

        }
    }
}
