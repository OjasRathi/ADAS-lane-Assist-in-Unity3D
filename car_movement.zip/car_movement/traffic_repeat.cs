using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class traffic_repeat : MonoBehaviour
{

    public Transform[] lane;
    public GameObject[] trafficvehicles;
    [SerializeField] car_controller carcontroller;
    public float Minspawnrate = 30f;
    public float maxspawnrate = 80f;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(trafficspawner());
    }

    IEnumerator trafficspawner()

    {
        yield return new WaitForSeconds(2f);

        while (true)
        {
            float dynamicTimer = Random.Range(Minspawnrate, maxspawnrate) / carcontroller.carspeed();
            if(carcontroller.carspeed()>10f)
            {
                Spawntrafficvehicle();
            }
            yield return new WaitForSeconds(dynamicTimer);

        }
        
    }

    void Spawntrafficvehicle()
    {
        int randomlaneindex = Random.Range(0, lane.Length);
        int randomvehicle = Random.Range(0, trafficvehicles.Length);
        Instantiate(trafficvehicles[randomvehicle], lane[randomlaneindex].position, Quaternion.identity);
        
    }

    
}
