using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;

public class AutonomousCarAgent : Agent
{
    // --- Physics Components ---
    [Header("Physics Setup")]
    public WheelCollider frontRight;
    public WheelCollider frontLeft;
    public WheelCollider rearRight;
    public WheelCollider rearLeft;

    public Transform frontRightTransform;
    public Transform frontLeftTransform;
    public Transform rearRightTransform;
    public Transform rearLeftTransform;

    public Rigidbody carRigidbody;
    public Transform COMTransform; // Center of Mass

    // --- Car Control Parameters ---
    [Header("Control Parameters")]
    private const float motorForceValue = 10000f; // Increased for better movement
    private const float steeringAngle = 30f;
    private const float brakeTorque = 5000f;

    // Inputs from NN
    private float currentThrottleInput;
    private float currentSteeringInput;

    // --- Initialization ---
    void Start()
    {
        if (carRigidbody != null && COMTransform != null)
        {
            carRigidbody.centerOfMass = COMTransform.localPosition;
        }
    }

    // --- ML-Agents Core Methods ---
    public override void OnEpisodeBegin()
    {
        // Reset position and rotation
        transform.localPosition = new Vector3(0, 0.5f, 0);
        transform.localRotation = Quaternion.identity;

        // Reset velocity
        carRigidbody.velocity = Vector3.zero;
        carRigidbody.angularVelocity = Vector3.zero;

        ApplyBrake(0f);
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        sensor.AddObservation(CarSpeed() / 100f); // Normalized speed
        sensor.AddObservation(transform.forward); // Forward direction
        sensor.AddObservation(carRigidbody.velocity); // Local velocity
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        currentThrottleInput = actions.ContinuousActions[0];
        currentSteeringInput = actions.ContinuousActions[1];

        ApplyMotorForce(currentThrottleInput);
        ApplySteering(currentSteeringInput);

        if (currentThrottleInput < 0)
        {
            ApplyBrake(brakeTorque * Mathf.Abs(currentThrottleInput));
        }
        else
        {
            ApplyBrake(0f);
        }

        // --- Rewards ---
        float forwardVelocity = Vector3.Dot(carRigidbody.velocity, transform.forward);
        AddReward(forwardVelocity * 0.001f);

        if (forwardVelocity < 1.0f && Mathf.Abs(currentThrottleInput) > 0.1f)
        {
            AddReward(-0.0005f);
        }
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var continuousActions = actionsOut.ContinuousActions;
        continuousActions[0] = Input.GetAxis("Vertical");
        continuousActions[1] = Input.GetAxis("Horizontal");
    }

    // --- Physics Handling ---
    void FixedUpdate()
    {
        UpdateWheelPoses();
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Wall") || collision.gameObject.CompareTag("Obstacle"))
        {
            SetReward(-1f);
            EndEpisode();
        }
    }

    // --- Car Physics Functions ---
    void ApplyMotorForce(float input)
    {
        float torque = motorForceValue * input;
        frontRight.motorTorque = torque;
        frontLeft.motorTorque = torque;
        rearRight.motorTorque = torque;
        rearLeft.motorTorque = torque;
    }

    void ApplySteering(float input)
    {
        float angle = steeringAngle * input;
        frontLeft.steerAngle = angle;
        frontRight.steerAngle = angle;
    }

    void ApplyBrake(float brake)
    {
        frontLeft.brakeTorque = brake;
        frontRight.brakeTorque = brake;
        rearLeft.brakeTorque = brake;
        rearRight.brakeTorque = brake;
    }

    public float CarSpeed()
    {
        return carRigidbody.velocity.magnitude * 2.23693629f; // m/s to MPH
    }

    void UpdateWheelPoses()
    {
        UpdateWheelPose(frontLeft, frontLeftTransform);
        UpdateWheelPose(frontRight, frontRightTransform);
        UpdateWheelPose(rearLeft, rearLeftTransform);
        UpdateWheelPose(rearRight, rearRightTransform);
    }

    void UpdateWheelPose(WheelCollider collider, Transform wheelTransform)
    {
        Vector3 pos;
        Quaternion rot;
        collider.GetWorldPose(out pos, out rot);
        wheelTransform.position = pos;
        wheelTransform.rotation = rot;
    }
}
