using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class UI_manager : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI Speedtext;
    [SerializeField] car_controller carcontrol;
    [SerializeField] TextMeshProUGUI distanceText;
    [SerializeField] Transform Cartransform;
    private float speed = 0f;
    private float distance = 0f;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        speedui();
        DistanceUI();
    }

    void DistanceUI()
    {
        distance = Cartransform.position.z/1000;
        distanceText.text = distance.ToString("0.00" + "KM");

    }
    void speedui()
    {
        speed = carcontrol.carspeed();
        Speedtext.text = speed.ToString("0" + "km/hr");

    }
}
