﻿using System.Collections;

using System.Collections.Generic;

using UnityEngine;

using System.IO;

using System.Threading.Tasks; // <-- for async writing



#if UNITY_EDITOR

using UnityEditor;

#endif



[RequireComponent(typeof(Camera))]

public class snap_shot_camera : MonoBehaviour

{

    Camera Snapcam;

    int resWidth = 256;

    int resHeight = 256;



    [Header("Car to follow (optional)")]

    public Transform car; // Assign your car in Inspector if you want to auto-follow



    void Start()

    {

        Snapcam = GetComponent<Camera>();



        // Automatically parent to car if assigned

        if (car != null)

        {

            transform.SetParent(car, true); // keep current local position/rotation

        }



        if (Snapcam.targetTexture == null)

        {

            Snapcam.targetTexture = new RenderTexture(resWidth, resHeight, 24);

        }

        else

        {

            resWidth = Snapcam.targetTexture.width;

            resHeight = Snapcam.targetTexture.height;

        }



        Snapcam.gameObject.SetActive(false);



        Debug.Log("📷 Snapshot camera initialized. Press 'C' to take snapshot.");

    }



    void Update()

    {

        // Press "C" to take snapshot

        if (Input.GetKeyDown(KeyCode.C))

        {

            Debug.Log("✅ C key pressed - snapshot requested");

            CallTakeSnapshot();

        }

    }



    public void CallTakeSnapshot()

    {

        Snapcam.gameObject.SetActive(true);

        StartCoroutine(TakeSnapshotCoroutine());

    }



    private IEnumerator TakeSnapshotCoroutine()

    {

        yield return new WaitForEndOfFrame(); // Wait for frame to finish



        Texture2D snapshot = new Texture2D(resWidth, resHeight, TextureFormat.RGB24, false);



        Snapcam.Render();

        RenderTexture.active = Snapcam.targetTexture;



        snapshot.ReadPixels(new Rect(0, 0, resWidth, resHeight), 0, 0);

        snapshot.Apply();



        // Convert texture to PNG byte array on main thread

        byte[] bytes = snapshot.EncodeToPNG();

        string fileName = SnapshotName();



        // Save PNG asynchronously on background thread

        Task.Run(() =>

        {

            File.WriteAllBytes(fileName, bytes);

#if UNITY_EDITOR

            // Refresh must be called on main thread, so we can use Unity's editor delay

            UnityEditor.EditorApplication.delayCall += () =>

            {

                AssetDatabase.Refresh();

            };

#endif

        });



        Snapcam.gameObject.SetActive(false);



        Debug.Log("✅ Snapshot captured and saving asynchronously at: " + fileName);

    }



    string SnapshotName()

    {

        string folderPath = Application.dataPath + "/Snapshots/";

        if (!Directory.Exists(folderPath))

        {

            Directory.CreateDirectory(folderPath);

        }



        return string.Format("{0}/snap_{1}x{2}_{3}.png",

        folderPath,

        resWidth,

        resHeight,

        System.DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss"));

    }

}