using UnityEngine;

public class Follow_carcam : MonoBehaviour
{
    [Header("References")]
    public Transform carTransform;           // assign your car's root transform here

    [Header("Mouse/Feedback")]
    public float mouseSensitivity = 3f;
    public float rotationSmoothTime = 0.06f;
    public float positionSmoothTime = 0.06f;
    public float minPitch = -40f;
    public float maxPitch = 60f;
    public bool lockCursor = false;

    // internal state
    private Vector3 localOffset;   // camera position in car's local space (keeps same transform)
    private float yaw;             // local yaw relative to car
    private float pitch;           // local pitch relative to car
    private float currentYaw;
    private float currentPitch;
    private float yawVel;
    private float pitchVel;
    private Vector3 posVel;

    void Start()
    {
        if (carTransform == null)
        {
            Debug.LogError("FollowCarCameraWithMouse: carTransform not assigned. Disabling.");
            enabled = false;
            return;
        }

        // store the camera's position *relative to the car* so it will move with the car
        localOffset = carTransform.InverseTransformPoint(transform.position);

        // store the camera's rotation relative to the car (local rotation)
        Quaternion localRot = Quaternion.Inverse(carTransform.rotation) * transform.rotation;
        Vector3 localEuler = localRot.eulerAngles;
        localEuler.x = NormalizeAngle(localEuler.x);
        localEuler.y = NormalizeAngle(localEuler.y);

        // initial local yaw/pitch (we add mouse deltas to these)
        yaw = currentYaw = localEuler.y;
        pitch = currentPitch = localEuler.x;

        if (lockCursor)
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }
    }

    void LateUpdate()
    {
        // read mouse input and update target local yaw/pitch
        yaw += Input.GetAxis("Mouse X") * mouseSensitivity;
        pitch -= Input.GetAxis("Mouse Y") * mouseSensitivity;
        pitch = Mathf.Clamp(pitch, minPitch, maxPitch);

        // smooth the local rotation values
        currentYaw = Mathf.SmoothDampAngle(currentYaw, yaw, ref yawVel, rotationSmoothTime);
        currentPitch = Mathf.SmoothDampAngle(currentPitch, pitch, ref pitchVel, rotationSmoothTime);

        // rebuild world rotation from car rotation + local (mouse-controlled) rotation
        Quaternion targetLocalRotation = Quaternion.Euler(currentPitch, currentYaw, 0f);
        transform.rotation = carTransform.rotation * targetLocalRotation;

        // keep camera at the same relative position to car (in car's local space)
        Vector3 targetWorldPos = carTransform.TransformPoint(localOffset);
        transform.position = Vector3.SmoothDamp(transform.position, targetWorldPos, ref posVel, positionSmoothTime);
    }

    // helper to convert 0..360 euler to -180..180
    private float NormalizeAngle(float a)
    {
        if (a > 180f) a -= 360f;
        return a;
    }
}
